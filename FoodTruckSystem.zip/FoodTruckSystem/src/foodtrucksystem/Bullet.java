package foodtrucksystem;

    public class Bullet extends FoodTruck {

        private int No_Tables;

        public Bullet() {
            super();
        }

        public Bullet(String id, double price, double price_of_servedOnePerson) {
            super(id, price, price_of_servedOnePerson);
            
        }

        public void Rent() {
            super.setAvailable(false);
        }

        public void Termination_of_rent() {
            super.setAvailable(true);
            super.setNo_Of_Worker(0);
            super.setNumberOfServed(20);//*********30
            //super.setPrice(0);***********
            this.setNo_Tables(0);
        }

        public void printDiscreption() {
            System.out.println("");
            System.out.println("Cart main information : \n " + super.toString());
            System.out.println("****** Bullet ******");
            System.out.println("We will provide hot and cold drinks, burger sandwiches,\n"
                    + "cheese and french fries, \n"
                    + "in addition to a main dish consisting of a type of meat and rice with steamed vegetables");
            System.out.println("Number of table : " + this.getNo_Tables());
            System.out.println("==============================================");

        }

        public double calculatePrice() {
            double sum = super.getPrice();
            sum = sum + (super.getNo_Of_Worker() * price_One_Worker);
            sum = sum + (super.getNumberOfServed() * price_of_servedOnePerson);
            sum = sum + (this.getNo_Tables() * priceOfTable);
            super.setPrice(sum);
            return sum;

        }

        public int getNo_Tables() {
            return No_Tables;
        }

        public void setNo_Tables(int No_Tables) {
            this.No_Tables = No_Tables;
        }

        public String toString() {
            String str = super.toString() + " ,number of Tables : " + No_Tables;

            return str;
        }

    }

