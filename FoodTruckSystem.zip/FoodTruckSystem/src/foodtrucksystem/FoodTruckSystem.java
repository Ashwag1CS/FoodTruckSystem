package foodtrucksystem;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.util.Formatter;
import java.util.InputMismatchException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class FoodTruckSystem {
    //    Super class          Sub Classes

    static FoodTruck[] trucks = new FoodTruck[9];
    static ArrayList<Order> orders = new ArrayList<Order>();
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {

        new showMassage();
        FillFoodTruck();

        System.out.println(ConsoleColors.CYAN_BACKGROUND + "Welcome in Food Truck System" + ConsoleColors.RESET);

        int ch = 0;
        do {
            try {
                System.out.println("1- Add new order ");
                System.out.println("2- Cancel one truck from exist order ");
                System.out.println("3- Cancel order ");
                System.out.println("4- Search and print order ");
                System.out.println("5- Save all ordered to file ");
                System.out.println("6- Exit ");
                System.out.print("\nEnter your choice>> ");
                ch = input.nextInt();

                switch (ch) {
                    case 1:
                        addNewOrder();
                        break;

                    case 2:
                        CancelOneTruck();
                        break;

                    case 3:
                        CancelOneOrder();
                        break;
                    case 4:
                        Order ord = SearchOrder();
                        if (ord != null) {
                            ord.PrintPill();
                        } else {
                            System.out.println("not found ");
                        }
                        break;

                    case 5:
                        saveToFile();
                        break;

                    case 6:
                        System.out.println("thank you for using our Services....Goodbye");
                        break;

                    default:
                        System.out.println("invalid choice.");

                }// end switch
            }//end try
            catch (InputMismatchException e) {
                input.next();//clean garbage from keyboard
                System.err.println("ERROR: Invalid input.");
            } catch (Exception e) {
                System.err.println("ERROR: Something went wrong.");
            }
        } while (ch != 6);

    }// end main 

    public static void FillFoodTruck() {//Trucks info 

        // polymorphism
        trucks[0] = new Bullet("Bullet1", 1000, 90); // id , price , price of worker
        trucks[1] = new Bullet("Bullet2", 1200, 90);
        trucks[2] = new Bullet("Bullet3", 1200, 90);
        trucks[3] = new StepVan("Van1", 900, 90);
        trucks[4] = new StepVan("Van2", 950, 90);
        trucks[5] = new StepVan("Van3", 1000, 90);
        trucks[6] = new TricycleCart("Tricycle1", 850, 90);
        trucks[7] = new TricycleCart("Tricycle2", 800, 90);
        trucks[8] = new TricycleCart("Tricycle3", 800, 90);

    }

    public static void showAvailbleFoodTruck() {
        System.out.println(ConsoleColors.YELLOW_BOLD + "---------------------------------------Trucks---------------------------------------" + ConsoleColors.RESET);
        for (FoodTruck truck : trucks) {
            if (truck.isAvailable() == true) {

                System.out.printf("%-20s  id : %-12s ", truck.getClass().getSimpleName(), truck.getId());//get simple name --> object type(class name)
                System.out.println(" ,  price : " + truck.getPrice() + " , cost per one guest :" + truck.getPrice_of_servedOnePerson());
            }
        }
        System.out.println(ConsoleColors.YELLOW_BOLD + "------------------------------------------------------------------------------------" + ConsoleColors.RESET);

    }

    public static FoodTruck search(String id) {
        for (FoodTruck truck : trucks) {
            if (truck.isAvailable() == true && truck.getId().equalsIgnoreCase(id)) {
                return truck;
            }
        }

        return null;
    }

    public static void addNewOrder() {

        System.out.println("Enter your SSN : ");
        String ssn = input.next();
        System.out.println("Enter your Mobile number : ");
        String mob = input.next();//next: read without a space
        System.out.println("Enter your full name : ");
        input.nextLine();
        String name = input.nextLine();//nextLine: read with a space
        System.out.println("Enter your address : ");
        String address = input.nextLine();

        Person person = new Person(ssn, mob, name, address);

        System.out.println("Enter day , month , year of order : ");
        Date date = new Date(input.nextInt(), input.nextInt(), input.nextInt());

        Order order = new Order(person, date);
        String ansr = "yes";
        while (ansr.equalsIgnoreCase("yes")) {//String-->.equals
            showAvailbleFoodTruck();

            System.out.println("Enter id of truck ");
            String id = input.next();

            FoodTruck truck = search(id);
            if (truck == null) {
                System.out.println("invalid id,try again.");
                continue; //continue the method
            }

            System.out.println("Enter number of Worker : ");
            int No_Of_Worker = input.nextInt();
            truck.setNo_Of_Worker(No_Of_Worker);
            System.out.println("Enter number of guest : ");
            int guest = input.nextInt();
            truck.setNumberOfServed(guest);

            if (truck instanceof Bullet) {//cuz the table only in bullet class
                System.out.println("Enter number of tables :");
                int table = input.nextInt();
                ((Bullet) truck).setNo_Tables(table);//down casting 
            } else if (truck instanceof TricycleCart) {
                System.out.println("Do you want toys with meal for kids ? ( yes or no ) ");
                String str = input.next();
                if (str.equalsIgnoreCase("yes")) {
                    ((TricycleCart) truck).setGiftToys(true);
                } else {
                    ((TricycleCart) truck).setGiftToys(false);
                }
            }

            order.addTruck(truck);
            System.out.println("Do you want to add more truck for this order ? (yes or no) ");
            ansr = input.next();
        }// end while yes 

// read Extra Services 
        order.ConfirmExtraServices();

        System.out.println("Enter number of days for order : ");
        int days = input.nextInt();
        order.setNumberOfdays(days);

        orders.add(order);  // add to arraylist 
        JOptionPane.showMessageDialog(null, "New order is add successfully !!");
        JOptionPane.showMessageDialog(null, "Your order's id : " + order.getOrderId());

    }

    public static void CancelOneTruck() {
        Order ord = SearchOrder();
        if (ord == null) {
            System.out.println("Not found.");
            return;
        }
        ord.PrintPill();
        System.out.println("Enter id of truck that you want to cancel : ");
        String id = input.next();
        ord.CancelTruck(id);

    }

    public static void CancelOneOrder() {
        Order ord = SearchOrder();
        if (ord != null) {
            ord.cancelAll();
            orders.remove(ord);
            System.out.println("cancel done.");
        } else {
            System.out.println("not found.");
        }
    }

    public static Order SearchOrder() {
        System.out.println("Enter id of order : ");
        String key = input.next();
        int intKey = Integer.parseInt(key);//convert to int

        for (Order ord : orders) {
            if (ord.getOrderId() == intKey || ord.getPerson().getMop().equals(key)) {
                return ord;
            }
        }

        return null;

    }

    public static void saveToFile() {
        try {
            Formatter file = new Formatter(new File("FoodTruckOrders.txt"));
            for (Order ord : orders) {
                file.format(ord.toString());
                file.format("==========================================================");
            }

            System.out.println("\nSave to file done.\n");
            file.close();
        } catch (FileNotFoundException ex) {
            System.err.println("ERROR: File not found.");
        } catch (IOException ex) {
            System.err.println("ERROR: Something went wrong.");

        }
    }

}

class showMassage {

    JFrame f;

    showMassage() {
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Hello, Welcome to Booking Food Truck System.");
    }
}

class ConsoleColors {

    // Reset
    public static final String RESET = "\033[0m";  // Text Reset

    public static final String YELLOW_BOLD = "\033[1;33m"; // YELLOW
    public static final String BLUE_BOLD = "\033[1;34m";   // BLUE
    public static final String PURPLE_BOLD = "\033[1;35m"; // PURPLE
    public static final String CYAN_BOLD = "\033[1;36m";   // CYAN

    // Background
    public static final String BLACK_BACKGROUND = "\033[40m";  // BLACK
    public static final String RED_BACKGROUND = "\033[41m";    // RED
    public static final String GREEN_BACKGROUND = "\033[42m";  // GREEN
    public static final String YELLOW_BACKGROUND = "\033[43m"; // YELLOW
    public static final String BLUE_BACKGROUND = "\033[44m";   // BLUE
    public static final String PURPLE_BACKGROUND = "\033[45m"; // PURPLE
    public static final String CYAN_BACKGROUND = "\033[46m";   // CYAN
   

  
}
