package foodtrucksystem;

public class StepVan extends FoodTruck {

    public StepVan() {
        super();
    }

    public StepVan(String id, double price, double price_of_servedOnePerson) {
        super(id, price, price_of_servedOnePerson);
    }

    public void Rent() {
        super.setAvailable(false);
    }

    public void Termination_of_rent() {
        super.setAvailable(true);
        super.setNo_Of_Worker(0);
        super.setNumberOfServed(20);
        
    }

    public void printDiscreption() {
        System.out.println("");
        System.out.println("Cart main information : \n " + super.toString());
        System.out.println("****** StepVan ******");
        System.out.println("we will provide a service of cold and hot drinks,\n"
                + " and three types of fast food, which are burger sandwiches, broasted, chicken nuggets\n"
                + "and quick desserts such as donuts, Cinnabon, and cookies");
        System.out.println("================================================");
    }

    public double calculatePrice() {
        double sum = super.getPrice();
        sum = sum + (super.getNo_Of_Worker() * price_One_Worker);
        sum = sum + (super.getNumberOfServed() * price_of_servedOnePerson);

        return sum;

    }
    //no aditional attrbuits ---> no to string

}
