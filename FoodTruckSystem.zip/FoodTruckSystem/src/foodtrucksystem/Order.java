package foodtrucksystem;

import java.util.ArrayList;
import java.util.Scanner;

public class Order {

    private Person person;//compistion
    ArrayList<FoodTruck> orderTrucks = new ArrayList<FoodTruck>();
    private double totalPrice;
    private Date date;//compistion
    private int numberOfdays;
    private static int counter = 1;
    private int OrderId;
    private final double discount = 0.15;

    Services[] servicesList = new Services[3];

    public Order(Person person, Date date) {
        this.person = person;
        OrderId = counter;
        counter++;
        totalPrice = 0;
        this.date = date;
        numberOfdays = 1;

        servicesList[0] = new Services(200, 0, "External heating");
        servicesList[1] = new Services(250, 0, "External cooling");
        servicesList[2] = new Services(100, 0, "Air games and jumping games");

    }

    public void addTruck(FoodTruck t) {
        orderTrucks.add(t);
        t.calculatePrice();
        t.Rent();
        calculateTotalPrice();
    }

    public void CancelTruck(String id) {
        for (FoodTruck obj : orderTrucks) {
            if (obj.getId().equals(id)) {
                orderTrucks.remove(obj);
                System.out.println("cancel done");
                obj.Termination_of_rent();
                calculateTotalPrice();

                return;
            }
        }
        System.out.println("Not found in order");
    }

    public void ConfirmExtraServices() {
        Scanner input = new Scanner(System.in);

        int ch = 0;
        while (ch != 4) {
            System.out.println("Enter number of choice of Exstra Service or 4 to exit :");
            System.out.println("1- " + servicesList[0].getName() + " , price : " + servicesList[0].getPrice());
            System.out.println("2- " + servicesList[1].getName() + " , price : " + servicesList[1].getPrice());
            System.out.println("3- " + servicesList[2].getName() + " , price : " + servicesList[2].getPrice());
            System.out.println("4- Exit .");

            ch = input.nextInt();
            switch (ch) {
                case 1:
                    servicesList[0].setConfirm(true);
                    System.out.println("Enter Quintity ");
                    servicesList[0].setQuantity(input.nextInt());
                    break;
                case 2:
                    servicesList[1].setConfirm(true);
                    System.out.println("Enter Quintity ");
                    servicesList[1].setQuantity(input.nextInt());
                    break;
                case 3:
                    servicesList[2].setConfirm(true);
                    System.out.println("Enter Quintity ");
                    servicesList[2].setQuantity(input.nextInt());
                    break;
            }

        }//  end while

        calculateTotalPrice();
    }

    public void calculateTotalPrice() {

        totalPrice = 0;
        for (FoodTruck obj : orderTrucks) {
            totalPrice = totalPrice + obj.calculatePrice();
        }

        if (orderTrucks.size() >= 2) {//discount if the user choose more than 2 trucks 
            totalPrice = totalPrice - (totalPrice * discount);
        }

        for (Services S : servicesList) {
            if (S.isConfirm() == true) {
                totalPrice = totalPrice + (S.getPrice() * S.getQuantity());
            }
        }

        totalPrice = totalPrice * this.numberOfdays;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public ArrayList<FoodTruck> getOrderTrucks() {
        return orderTrucks;
    }

    public void setOrderTrucks(ArrayList<FoodTruck> orderTrucks) {
        this.orderTrucks = orderTrucks;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public int getOrderId() {
        return OrderId;
    }

    public void setOrderId(int OrderId) {
        this.OrderId = OrderId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getNumberOfdays() {
        return numberOfdays;
    }

    public void setNumberOfdays(int numberOfdays) {
        if (numberOfdays > 0 && numberOfdays < 5) {
            this.numberOfdays = numberOfdays;
        } else {
            this.numberOfdays = 1;
        }
        this.calculateTotalPrice();
    }

    public Services[] getServicesList() {
        return servicesList;
    }

    public void setServicesList(Services[] servicesList) {
        this.servicesList = servicesList;
    }

    public void PrintPill() {
        System.out.println("***************************");
        System.out.println("Order : \n "
                + "OrderId : " + OrderId + "\n"
                + "Date : " + date + "\n"
                + "person : " + person
                + "\norderTrucks : \n"
                + "\ntotalPrice =" + totalPrice + "\n");

        System.out.println("All trucks info : ");
        for (FoodTruck obj : orderTrucks) {
            obj.printDiscreption();
        }

        System.out.println("** Extra Services : **");
        for (Services S : servicesList) {
            if (S.isConfirm() == true) {
                System.out.println(S.toString());
            }
        }
        System.out.println("");
    }
    public void cancelAll(){
        for (FoodTruck obj : orderTrucks) {
                orderTrucks.remove(obj);
                obj.Termination_of_rent();
        }
    }

    public String toString() {
        String str = "OrderId : " + OrderId + "\n"
                + "Date : " + date + "\n"
                + "person : " + person
                + "\norderTrucks : \n"
                + "\ntotalPrice=" + totalPrice + "\n"
                + "all trucks info : \n";

        for (FoodTruck obj : orderTrucks) {
            str = str + obj.toString() + "\n";
        }

        str = str + "** Extra Services : **" + "\n";
        for (Services S : servicesList) {
            if (S.isConfirm() == true) {
                str = str + S.toString() + "\n";
            }
        }
        return str;
    }

}
