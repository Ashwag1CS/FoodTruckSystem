package foodtrucksystem;

public class TricycleCart extends FoodTruck {

    private boolean giftToys;

    public TricycleCart() {
        super();
    }

    public TricycleCart(String id, double price, double price_of_servedOnePerson) {
        super(id, price, price_of_servedOnePerson);
    }

    public void Rent() {
        super.setAvailable(false);
    }

    public void Termination_of_rent() {
        super.setAvailable(true);
        super.setNo_Of_Worker(0);
        super.setNumberOfServed(20);
        //super.setPrice(0);**********
        this.setGiftToys(false);
    }

    public void printDiscreption() {
        System.out.println("");
        System.out.println("Cart main information : \n " + super.toString());
        System.out.println("****** TricycleCart ******");
        System.out.println("We will provide cold drinks service, with three types of children's fast meals,\n"
                + "including gifts for children(According to the customer's desire) and a drink, cheesecake, donuts, and cookies");
        System.out.println("==============================================");

    }

    public double calculatePrice() {
        double sum = super.getPrice();
        sum = sum + (super.getNo_Of_Worker() * price_One_Worker);
        sum = sum + (super.getNumberOfServed() * price_of_servedOnePerson);
        if (isGiftToys() == true) {
            sum = sum + (getNumberOfServed() * 5); // 5 price of one toy
        }
        return sum;

    }

    public boolean isGiftToys() {
        return giftToys;
    }

    public void setGiftToys(boolean giftToys) {
        this.giftToys = giftToys;
    }

    public String toString() {
        String str = super.toString();
        if (this.giftToys == true) {
            str = str + " , and giftoys with meal ";
        }
        return str;
    }

}
