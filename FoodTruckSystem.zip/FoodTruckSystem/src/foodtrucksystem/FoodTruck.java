package foodtrucksystem;

public abstract class FoodTruck implements FoodInf {

    private boolean available;
    private double price;
    private int No_Of_Worker;
    private String id;
    private int numberOfServed;  // Number of people benefiting from truck
    protected double price_of_servedOnePerson;
    protected final int Min_No_person = 20;

    public FoodTruck() {
        available = true;
        No_Of_Worker = 0;
        price_of_servedOnePerson = 50; // default price
    }

    public FoodTruck(String id, double price, double price_of_servedOnePerson) {
        available = true;
        this.id = id;
        No_Of_Worker = 0;
        this.price = price;
        this.price_of_servedOnePerson = price_of_servedOnePerson;
    }

    public abstract void Rent();

    public abstract void Termination_of_rent();

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getNumberOfServed() {
        return numberOfServed;
    }

    public void setNumberOfServed(int numberOfServed) {
        if (numberOfServed < Min_No_person) {
            System.out.println("sorry least number of guest allowed is " + Min_No_person);
            this.numberOfServed = Min_No_person;
        } else {
            this.numberOfServed = numberOfServed;
        }

    }

    public int getNo_Of_Worker() {
        return No_Of_Worker;
    }

    public void setNo_Of_Worker(int No_Of_Worker) {
        this.No_Of_Worker = No_Of_Worker;
    }

    public double getPrice_of_servedOnePerson() {
        return price_of_servedOnePerson;
    }

    public void setPrice_of_servedOnePerson(double price_of_servedOnePerson) {
        this.price_of_servedOnePerson = price_of_servedOnePerson;
    }

    @Override
    public String toString() {
        return " id= " + id + " , available= " + available + ", price= " + price
                + ", NoWorker= " + No_Of_Worker
                + ", number of guest = " + numberOfServed + "\n";
    }

}
