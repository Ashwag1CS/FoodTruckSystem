
package foodtrucksystem;

public class Services {

    private double price;
    private int Quantity;
    private String Name;
    private boolean confirm;

    public Services() {
    }

    public Services(double price, int Quantity, String Name) {
        this.price = price;
        this.Quantity = Quantity;
        this.Name = Name;
        confirm = false;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public boolean isConfirm() {
        return confirm;
    }

    public void setConfirm(boolean confirm) {
        this.confirm = confirm;
    }

    @Override
    public String toString() {
        return "* Name of Service" + Name + " ,price=" + price + ",Quantity=" + Quantity;
    }

}
