package foodtrucksystem;

public class Person {

    private String ssn;
    private String Mop;
    private String FullName;
    private String address;

    public Person() {
    }

    public Person(String ssn, String Mop, String FullName, String address) {
        this.ssn = ssn;
        this.Mop = Mop;
        this.FullName = FullName;
        this.address = address;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getMop() {
        return Mop;
    }

    public void setMop(String Mop) {
        this.Mop = Mop;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "ssn=" + ssn + ", Mop=" + Mop + ", FullName=" + FullName + ", address=" + address;
    }

}
