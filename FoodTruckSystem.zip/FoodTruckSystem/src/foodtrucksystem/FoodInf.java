
package foodtrucksystem;

public interface FoodInf {

public static final double price_One_Worker = 50 ; 
public static final double priceOfTable = 30 ; 


public abstract void printDiscreption() ;   
public abstract double calculatePrice() ; 
}
